package regex;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//Main class
public class regxx 
{

	// Main driver method
	public static void main(String args[])
	{

		// Creating a pattern to be searched
		Pattern pattern = Pattern.compile("ad*", Pattern.CASE_INSENSITIVE);
		Matcher m = pattern.matcher("AdityaBirla.net");

		while (m.find())

		
			System.out.println("Pattern found from "
							+ m.start() + " to "
							+ (m.end() - 1));
	}
}

