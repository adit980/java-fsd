package modifier;

public class pkg 
{
	

		protected void display() 
	    { 
	        System.out.println("This is protected access specifier"); 
	    } 
	}

