package modifier2;


import modifier.pkg;

public class propkg extends pkg {

	public static void main(String[] args) {
		propkg obj = new propkg ();   
	       obj.display();  
	}

}