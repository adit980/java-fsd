package collection;

import java.util.*;

public class collections {

	public static void main(String[] args) {
		//creating arraylist
		System.out.println("ArrayList");
		ArrayList<String> name=new ArrayList<String>();
		ArrayList<Integer> num=new ArrayList<Integer>();
	      name.add("aman");
	      name.add("anil");    
	      num.add(1);
	      num.add(2);
	      System.out.println(num);
	      System.out.println(name);  
		
		//creating vector
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> v = new Vector();
	      v.addElement(300); 
	      v.addElement(500); 
	      System.out.println(v);
		
		//creating linkedlist
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<Integer> list= new LinkedList<Integer>();
			
			list.add(56);
			list.add(67);
			list.add(89);
			list.add(13);
			
			System.out.println("Size: "+list.size());
			System.out.println(list);
			
			list.remove(3);
			
			System.out.println(list);
			
			System.out.println("Element 2: "+list.get(2));
			list.add(2,0);
			
			System.out.println(list);  
	       
	       //creating hashset
	       System.out.println("\n");
	       System.out.println("HashSet");
	       HashSet<Integer> set= new HashSet<Integer>();
			
			set.add(20);
			set.add(55);
			set.add(2);
			set.add(36);
			set.add(67);
			set.add(67);
			set.add(null);
			
			System.out.println("Size: "+set.size());
			
			System.out.println(set);
			
			System.out.println("Contains: "+ set.contains(55));
	       
	       //creating linkedhashset
	       System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<String> linkedset= new LinkedHashSet<String>();
			
			linkedset.add("A");
			linkedset.add("B");
			linkedset.add("C");
			linkedset.add("D");
			
			//note: do not allows duplicate values, so 'A' will not be added but 'E' will be added
			linkedset.add("A");
			linkedset.add("E");
			linkedset.add(null);
			
			System.out.println("Size: "+linkedset.size());
			
			System.out.println(linkedset);
	      	} 
	      }  
	
