package clz;

public class clz1 {

	 private String msg="yes you are here"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+"----now you got into inner");}  
	 }  


	public static void main(String[] args) {

		clz1 obj=new clz1();
		clz1.Inner in=obj.new Inner();  
		in.hello();  
	}
}

