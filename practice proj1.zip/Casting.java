package assign;

public class Casting
{
	

		public static void main(String[] args) 
		{
			
			//implicit conversion
			System.out.println("Implicit Type Casting");
			char ch='g';
			System.out.println("Value of a: "+ch);
			
			int num=ch;
			System.out.println("Value of b: "+num);
			
			float f=ch;
			System.out.println("Value of c: "+f);
			
			long l=ch;
			System.out.println("Value of d: "+l);
			
			double e=ch;
			System.out.println("Value of e: "+e);
			
					
			System.out.println("\n");
			
			System.out.println("Explicit Type Casting");
			//explicit conversion
			
			double x=876.5;
			int y=(int)x;
			System.out.println("Value of x: "+x);
			System.out.println("Value of y: "+y);
			
		}
	}



